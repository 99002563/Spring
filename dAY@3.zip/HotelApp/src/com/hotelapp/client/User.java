package com.hotelapp.client;

import java.util.List;

import com.hotelapp.model.Hotel;
import com.hotelapp.service.HotelService;
import com.hotelapp.service.HotelServiceImpl;

public class User {
	public static void main(String[] args) {
		HotelService hotelService = new HotelServiceImpl();
		List<Hotel> hotelList = hotelService.getAllHotels();

		for (Hotel hotel : hotelList)
			System.out.println(hotel);

		List<Hotel> hotel2 = hotelService.getByCity("Patna");
		//for (Hotel hotel : hotelList)
			System.out.println(hotel2);
			
			List<Hotel> hotel3 =  hotelService.getByCuisine("Noodles");
			System.out.println(hotel3);
			System.out.println(hotelService.getById(1));
			
	}

}
