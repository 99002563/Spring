package com.ltts.foodwiring;

import java.util.List;

public interface Menu {
	List<String> itemsAvailable();
}
