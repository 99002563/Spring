package com.ltts.jbased;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;

import com.ltts.autowiring.Rectangle;
import com.ltts.autowiring.Shape;
import com.ltts.autowiring.ShapeFactory;
import com.ltts.autowiring.Triangle;

@Configuration
public class AppConfig {

	
	@Bean
	public Vehicle getVehicle() {
		return new Vehicle();
	}
	
	@Bean
	public Shape getTriangle() {
		return new Triangle();
	}
	
	@Bean
	@Primary
	public Shape getRectangle() {
		return new Rectangle();
	}
	@Bean
	public ShapeFactory getFactory() {
		return new ShapeFactory();
	}
}
