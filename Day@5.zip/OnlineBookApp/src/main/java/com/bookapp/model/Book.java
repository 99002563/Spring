package com.bookapp.model;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.AllArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class Book {

	Integer bookId;
	String title;
	String author;
	String category;
	Double price;
	//public int getBookId;
	
	
}
